document.getElementById('extract').addEventListener('click', async () => {
  const statusDiv = document.getElementById('status');
  const outputDiv = document.getElementById('output');
  const copyBtn = document.getElementById('copy');
  
  // Reset UI
  statusDiv.innerHTML = '<div class="status">extracting...</div>';
  outputDiv.classList.remove('show');
  copyBtn.style.display = 'none';
  
  try {
    // Get current tab
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    
    if (!tab.url.includes('netflix.com')) {
      statusDiv.innerHTML = '<div class="status error">open netflix first</div>';
      return;
    }

    // Get all Netflix cookies
    chrome.cookies.getAll({ domain: '.netflix.com' }, (cookies) => {
      if (chrome.runtime.lastError) {
        statusDiv.innerHTML = '<div class="status error">error: ' + chrome.runtime.lastError.message + '</div>';
        return;
      }

      if (!cookies || cookies.length === 0) {
        statusDiv.innerHTML = '<div class="status error">no cookies found</div>';
        return;
      }

      // Extract important cookies
      const cookiePairs = [];
      let foundNetflixId = false;

      cookies.forEach(cookie => {
        if (cookie.name === 'NetflixId') {
          cookiePairs.push(`NetflixId=${cookie.value}`);
          foundNetflixId = true;
        } else if (cookie.name === 'SecureNetflixId') {
          cookiePairs.push(`SecureNetflixId=${cookie.value}`);
        }
      });

      if (!foundNetflixId) {
        statusDiv.innerHTML = '<div class="status error">login to netflix first</div>';
        return;
      }

      // Format output as key=value;key=value
      const cookieString = cookiePairs.join(';');
      
      statusDiv.innerHTML = '<div class="status success">done</div>';
      outputDiv.textContent = cookieString;
      outputDiv.classList.add('show');
      copyBtn.style.display = 'block';
      
      // Copy button handler
      copyBtn.onclick = () => {
        navigator.clipboard.writeText(cookieString).then(() => {
          const originalText = copyBtn.textContent;
          copyBtn.textContent = 'copied';
          setTimeout(() => {
            copyBtn.textContent = originalText;
          }, 1500);
        }).catch(err => {
          statusDiv.innerHTML = '<div class="status error">copy failed</div>';
        });
      };
    });

  } catch (error) {
    statusDiv.innerHTML = '<div class="status error">error: ' + error.message + '</div>';
  }
});
