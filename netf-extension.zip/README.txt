================================
NETFLIX COOKIE AUTO-EXTRACTOR
Chrome Extension
================================

CARA INSTALL:
-------------

1. Buka Chrome

2. Pergi ke: chrome://extensions/

3. Enable "Developer mode" (toggle di kanan atas)

4. Klik "Load unpacked"

5. Pilih folder "netflix-extension"

6. Extension terinstall!


CARA PAKAI:
-----------

1. Buka netflix.com dan login

2. Klik icon extension di toolbar (icon Netflix merah)

3. Klik tombol "Extract Cookies"

4. Cookies akan muncul otomatis!

5. Klik "Copy to Clipboard" untuk copy


HASIL:
------

Extension akan extract:
{
  "NetflixId": "v%3D3%26ct%3D...",
  "SecureNetflixId": "v%3D3%26mac%3D..."
}

Format JSON yang bisa langsung dipake.


CATATAN:
--------

- Extension ini hanya bisa akses cookies dari netflix.com
- Hanya extract NetflixId dan SecureNetflixId
- Cookie values sangat panjang (ratusan karakter)
- JANGAN share cookies ini dengan siapapun
- Cookies ini sama dengan login credentials


TROUBLESHOOTING:
----------------

Q: Extension tidak muncul?
A: Pastikan sudah enable "Developer mode" di chrome://extensions/

Q: Error "Please open Netflix first"?
A: Buka tab netflix.com dulu, baru klik extension

Q: "No cookies found"?
A: Login ke Netflix dulu

Q: "NetflixId cookie not found"?
A: Logout dan login ulang ke Netflix
